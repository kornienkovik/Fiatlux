# [picture-vs-img](https://gennadiy1970.github.io/picture-vs-img/.)
